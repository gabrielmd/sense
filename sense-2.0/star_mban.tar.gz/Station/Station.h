#include "../FlowGen/FlowGen.h"
#include "../Source/Source.h"

component Station : public TypeII{
	public: 
		Source source;
		FlowGen flowgen;

		inport inline void flowGenIn(PACKET& p);	//to flowGen: ack from CAC
		outport void flowGenOut(PACKET& p);		//from flowGen: request to CAC
		outport void sourceOut(PACKET& p);		//from source: generated packets

		Station();
		virtual ~Station(){}; 
		void Setup(const char *, int);

	private:
		int StationNumber;
};

Station::Station(){	
	connect flowGenIn,flowgen.in;
	connect flowgen.control_out,source.in;
	connect flowgen.out,flowGenOut;
	connect source.out,sourceOut;
}

void Station :: Setup(const char *name, int id){
	StationNumber = id;
	source.Setup("source",id);
	flowgen.Setup("FlowGen",id);
};