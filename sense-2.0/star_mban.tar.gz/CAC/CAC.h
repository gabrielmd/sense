#include "../Defs/packet.h"

component CAC : public TypeII
{
	public: 
		inport inline void in(PACKET& request);
		outport void out(PACKET& response);

		CAC(){}; 
		virtual ~CAC(){}; 
		void Setup(const char *, int);
		void Start();
		void Stop();

	private:
		int CACNumber;

};

void CAC :: Setup(const char *name, int id)
{
	CACNumber = id;

};

void CAC :: Start(){	
};

void CAC :: Stop(){
};

void CAC :: in(PACKET &request)
{

PACKET response;

	if (request.destination == CACNumber)
		//printf("\nCAC -> Received FlowRequest packet from %d at %f",request.source, SimTime());
	
	response.source = CACNumber;
	response.destination = request.source;
	response.status = ACCEPT;
	//printf("\nCAC -> Send FlowResponse packet from %d at %f",response.source, SimTime());
	out(response);
};

