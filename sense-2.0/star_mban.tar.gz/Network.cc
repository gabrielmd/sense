#include "../common/cost.h"

#include "Station/Station.h"
#include "Sink/Sink.h"
#include "Bridge/Bridge.h"
#include "Stats/stats.h"
#include "Empty/empty.h"

component Network : public CostSimEng
{
	private: 
		int n_stations;
		int n_bridges;
		int n_sinks;

		Station[] station;
		Bridge[] bridge;
		Sink[] sink;
		Stats stats;
		Empty empty;

	public:
		Network();
		void Setup(const char *);
		void Stop();
		void Start();

		inport inline void start_stats_collection(trigger_t& t);	//port associated to the servce timer
		Timer<trigger_t> start_stats;			//timer to start collecting statistic
};

Network::Network(){					
	//initialize component Network variable
	n_stations = 7;
	n_sinks = 7;
	n_bridges = 7;
	
	station.SetSize(n_stations);
	bridge.SetSize(n_bridges);
	sink.SetSize(n_sinks);

	connect start_stats.to_component,start_stats_collection;
}

void Network :: Start(){
	printf("start!\n\n");
	start_stats.Set(9); //time to start collecting stats: 9 sec (after all ports into forwarding)
}

void Network :: Stop(){
	printf("end of simulation!\n\n");
	stats.print_global_stats();
	stats.print_station_stats(n_stations);
	stats.print_bridge_port_stats(n_bridges,N_PORTS);
}

void Network :: start_stats_collection(trigger_t& t){
	stats.init_stats();
}

void Network :: Setup(const char *name){	//set up variables (internal and external)

	printf("Start Network Creation\n\n");

	//sources
	for(int n=0; n < n_stations; n++){
		station[n].Setup("station", n);
	}

	//Bridges
	for(int n=0; n < n_bridges; n++){
		bridge[n].Setup("bridge",n);	
	}
	
	//sinks
	for(int n=0; n < n_sinks; n++){
		sink[n].Setup("sink",n);
	}

	//6 bridges(4 aports) amb una estacio i una sink cadascun

	//bridge <-> bridge
	connect bridge[0].out1,bridge[1].in1;	//bridge 0 <-> bridge 1
	connect bridge[1].out1,bridge[0].in1;

	connect bridge[0].out2,bridge[2].in1;	//bridge 0 <-> bridge 2
	connect bridge[2].out1,bridge[0].in2;

	connect bridge[0].out3,bridge[3].in1;	//bridge 0 <-> bridge 3
	connect bridge[3].out1,bridge[0].in3;

	connect bridge[0].out4,bridge[4].in1;	//bridge 0 <-> bridge 4
	connect bridge[4].out1,bridge[0].in4;

	connect bridge[0].out5,bridge[5].in1;	//bridge 0 <-> bridge 6
	connect bridge[5].out1,bridge[0].in5;

	connect bridge[0].out6,bridge[6].in1;	//bridge 0 <-> bridge 1
	connect bridge[6].out1,bridge[0].in6;

	//bridge <-> station (source) - always in bridge port 0
	for(int s=0; s<n_stations ; s++){
		for(int b=0; b<n_bridges ; b++){
			connect station[s].sourceOut,bridge[b].in0;
			connect bridge[b].out0,sink[s].in;
		}
	}

	//bridge <-> station (CAC)
	for(int s=0; s<n_stations ; s++){
		for(int b=0; b<n_bridges ; b++){
			connect station[s].flowGenOut,bridge[b].cac_in;
			connect bridge[s].cac_out,station[b].flowGenIn;
		}
	}

	//all ports connected to empty (always highest port id's)
	for(int i=1; i<n_bridges; i++){ //all bridges except bridge 0 (root, center of star)
		connect bridge[i].out2,empty.in;
		connect bridge[i].out3,empty.in;
		connect bridge[i].out4,empty.in;
		connect bridge[i].out5,empty.in;
		connect bridge[i].out6,empty.in;
	}
		
	printf("End Network Setup\n\n");
	
};

int main(int argc, char* argv[]){

	Network network;
	network.Seed=1;
	network.StopTime=1000;
	network.Setup("Network");
	network.Run();
	return(0);
};
