function [] = plot_sim( Statistics )

color1 = 'blue';

x = Statistics(:,1)

figure(1);
axes('box', 'on','Ygrid','on', 'Xgrid', 'on');
hold on;
set(gcf,'Color', 'w');
xlabel('Change Cell Probability');
ylabel('Time (s)');
plot (x, Statistics(:,2),'-ko','Color',color1);
legend('All Stations Are Out the Cell', 2);
hold off;

end