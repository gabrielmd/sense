#include "../Defs/packet.h"

component Mobility : public TypeII{

	public: 
		Mobility();
		virtual ~Mobility(){}; 
		void Setup(const char *, int);
		outport void control_out(int& OldCell, int& NewCell);
		Timer <trigger_t> ComputeNewPosition;
		inport inline void timer_ComputeNewPosition(trigger_t& t);


	private:
		int StationNumber;
};

Mobility::Mobility(){		
	connect ComputeNewPosition.to_component,timer_ComputeNewPosition;
}

void Mobility :: Setup(const char *name, int id){

	StationNumber = id;
	ComputeNewPosition.Set(Tobs);		
	station_info[StationNumber].AttachedBridge = StationNumber;

};


void Mobility :: timer_ComputeNewPosition(trigger_t &){

int change = rand() % 101;
int OldCell;
int NewCell;

	OldCell = station_info[StationNumber].AttachedBridge;

	if(change < ProbHandoff){			//Change Cell

		NewCell = rand()%7;
		while(NewCell==station_info[StationNumber].AttachedBridge){
			NewCell = rand()%7; 
		}
		station_info[StationNumber].AttachedBridge = NewCell;
			if(PRINT_CAC==1)	printf("\n\t\t--Station %d - Change Cell from %d to %d--\n", StationNumber, OldCell, station_info[StationNumber].AttachedBridge);
		control_out(OldCell, NewCell);
	}
		
	ComputeNewPosition.Set(Tobs + SimTime());
};
